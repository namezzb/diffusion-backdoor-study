#!/usr/bin/env bash
set -euo pipefail

BD="${BD:-/opt/data/private/BackdoorDM}"
PY="${PY:-/opt/data/private/miniconda3/envs/eviledit/bin/python}"
RESULT="${RESULT:-results/invi_backdoor_DDPM-CELEBA-HQ-256}"
DEVICE="${DEVICE:-cuda:0}"
EVAL_MAX_BATCH="${EVAL_MAX_BATCH:-32}"
IMG_NUM="${IMG_NUM:-1000}"

export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
export OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-1}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-1}"
export NUMEXPR_NUM_THREADS="${NUMEXPR_NUM_THREADS:-1}"
export TOKENIZERS_PARALLELISM="${TOKENIZERS_PARALLELISM:-false}"
export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HUB_OFFLINE="${HF_HUB_OFFLINE:-1}"
export HF_DATASETS_OFFLINE="${HF_DATASETS_OFFLINE:-1}"

cd "$BD"

drop_page_cache() {
  sync || true
  if [[ -w /proc/sys/vm/drop_caches ]]; then
    echo 3 > /proc/sys/vm/drop_caches || true
  fi
}

if pgrep -af 'python.*invi_backdoor.py' >/dev/null; then
  echo "Refusing to run eval: InviBackdoor training is still active." >&2
  pgrep -af 'python.*invi_backdoor.py' >&2 || true
  exit 2
fi

"$PY" - <<'PY'
import sys, torch
p = "results/invi_backdoor_DDPM-CELEBA-HQ-256/data.ckpt"
ckpt = torch.load(p, map_location="cpu")
epoch = int(ckpt.get("epoch", -1))
step = int(ckpt.get("step", -1))
print({"epoch": epoch, "step": step})
if epoch < 49:
    raise SystemExit(f"Refusing to run eval: expected completed epoch >=49, got epoch={epoch}, step={step}")
PY

stale_dirs=(
  "$RESULT/FID_gen_cleanImg_CELEBA-HQ_${IMG_NUM}"
  "$RESULT/bd_generated_CELEBA-HQ_${IMG_NUM}"
)
for stale_dir in "${stale_dirs[@]}"; do
  if [[ -d "$stale_dir" ]]; then
    echo "Removing stale generated samples: $stale_dir"
    rm -rf "$stale_dir"
  fi
done

"$PY" evaluation/main_eval.py \
  --metric FID \
  --backdoor_method invi_backdoor \
  --backdoored_model_path "$RESULT" \
  --bd_result_dir "$RESULT" \
  --model_ver DDPM-CELEBA-HQ-256 \
  --val_data CELEBA-HQ \
  --img_num_FID "$IMG_NUM" \
  --eval_max_batch "$EVAL_MAX_BATCH" \
  --infer_steps 1000 \
  --device "$DEVICE"

drop_page_cache

"$PY" server/run_invi_mse_stream.py \
  --repo "$BD" \
  --out-dir "$RESULT/bd_generated_CELEBA-HQ_${IMG_NUM}" \
  --record-file "$RESULT/eval_results.csv" \
  --dataset-path datasets \
  --method invi_backdoor \
  --trigger INVI \
  --target HAT \
  --img-num "$IMG_NUM"

drop_page_cache

tail -10 "$RESULT/eval_results.csv"
