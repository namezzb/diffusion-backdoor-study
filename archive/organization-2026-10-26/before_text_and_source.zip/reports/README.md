# 📊 Reports 索引

> 扩散模型后门研究文档集合
> 最后更新：2026-10-23

## 当前研究方案

- [TSSA 梯度校准方案 v2](./01-background-research/tssa_response_calibration_method_proposal.md)：当前唯一方法提案，以固定差分组的 a、b 梯度优化兼顾后门响应与正常能力；尚未实现或执行本版实验。
- [上一版封存记录](./archive/2026-10-23-tssa-local-surrogate/README.md)：原有限差分及局部求解器方案按字节保留，附 SHA-256 校验与只读归档；不再作为当前执行依据。

---

## 📚 目录结构

```
reports/
├── README.md                          # 本索引文件
├── 01-background-research/            # 背景调研与当前方法方案
├── 02-cross-reference/                # 代码-论文交叉对照 (4 files)
├── 03-reproduction-results/           # 基准参考与历史实验报告
└── archive/                          # 已替代方案的只读快照与校验清单
```

> **注意**: 复现进度文档已移至项目根目录 `backdoordm_progress.md`。

---

## 🧪 03-reproduction-results/

**基准参考** — BackdoorDM 论文基准值 + 指标定义 + 脚本覆盖（只读，勿改）

| 文件名 | 内容 |
|--------|------|
| [backdoordm_reference.md](./03-reproduction-results/backdoordm_reference.md) | BackdoorDM 论文全部基准值表 (Table 3-16)、指标名称对照、31 种指标列表、防御输出 vs 论文参考值、官方脚本覆盖、配置修复、已知限制 |

---

## 🔬 01-background-research/

**背景调研** — 文献综述、论文精读、创新思路设计

| 文件名 | 内容 | 日期 |
|--------|------|------|
| [tssa_response_calibration_method_proposal.md](./01-background-research/tssa_response_calibration_method_proposal.md) | 当前 TSSA 梯度校准方案：双系数、固定β、正常保持、低算力验证与预算 | 2026-10-23 |
| [diffusion_backdoor_deep_survey_2025_2026.md](./01-background-research/diffusion_backdoor_deep_survey_2025_2026.md) | 2025-2026年扩散后门深度调研 | 2026-06-25 |
| [diffusion_backdoor_novel_ideas.md](./01-background-research/diffusion_backdoor_novel_ideas.md) | 10个顶会级创新思路 (英文版) | 2026-06-25 |
| [diffusion_backdoor_novel_ideas_zh.md](./01-background-research/diffusion_backdoor_novel_ideas_zh.md) | 10个顶会级创新思路 (中文版) | 2026-06-25 |
| [diffusion_backdoor_optimized_ideas_v2.md](./01-background-research/diffusion_backdoor_optimized_ideas_v2.md) | 创新方向收敛与优先级优化 | 2026-06-26 |
| [merge_backdoor_research_report.md](./01-background-research/merge_backdoor_research_report.md) | 检查点合并后门持久性研究 | 2026-06-25 |
| [paper_deep_reading_report.md](./01-background-research/paper_deep_reading_report.md) | 15篇扩散后门论文全文精读 | 2026-06-26 |

---

## 🔍 02-cross-reference/

**代码-论文交叉对照** — BackdoorDM 实现与原始论文的对比验证

| 文件名 | 内容 | 日期 |
|--------|------|------|
| [backdoordm_paper_crossref_summary.md](./02-cross-reference/backdoordm_paper_crossref_summary.md) | 全方法论文交叉验证汇总 | 2026-06-28 |
| [backdoordm_crossref_report.md](./02-cross-reference/backdoordm_crossref_report.md) | BackdoorDM 实现 vs 原始论文完整对照 | 2026-06-28 |
| [backdoordm_t2i_cross_reference_report.md](./02-cross-reference/backdoordm_t2i_cross_reference_report.md) | T2I 攻击方法专项交叉验证 | 2026-06-28 |
| [defense_cross_reference_report.md](./02-cross-reference/defense_cross_reference_report.md) | 防御方法交叉对照 | 2026-06-28 |

---

## 🔗 相关资源

- **进度文档**: `../backdoordm_progress.md`（可变，loop 每次更新）
- **循环指令**: `../LOOP.md`
- **论文 PDF**: `../papers/`（24 篇 PDF + 索引）
- **归档脚本**: `../archive/experiments/`（只读）
